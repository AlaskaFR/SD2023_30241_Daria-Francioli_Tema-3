package com.example.user.controller;

import com.example.user.service.ChatService;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Controller;
import com.example.user.dto.ChatDto;

@Controller
@RequiredArgsConstructor
public class ChatController {
    private final ChatService notificationService;

    @MessageMapping("/sendMessage")
    public void sendMessages(@Payload ChatDto message) {
        notificationService.sendMessages(message);
    }

    @MessageMapping("/isTyping")
    public void sendTyping(@Payload ChatDto message) {
        notificationService.sendTyping(message);
    }

    @MessageMapping("/seen")
    public void sendSeen(@Payload ChatDto message) {
        notificationService.sendSeen(message);
    }
}
