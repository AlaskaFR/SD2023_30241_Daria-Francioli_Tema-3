package com.example.user.model;

public enum Status {
    JOIN,
    MESSAGE,
    LEAVE
}
